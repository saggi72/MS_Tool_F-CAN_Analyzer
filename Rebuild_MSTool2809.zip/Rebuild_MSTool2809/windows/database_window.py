"""DatabaseWindow: quản lý CAN network + DBC, duyệt message / signal (Add CAN Database)."""
from __future__ import annotations

import csv
import logging
import os
import re
from typing import Any

from PyQt6.QtCore import QEvent, Qt, QTimer
from PyQt6.QtGui import QBrush, QColor, QFont
from PyQt6.QtWidgets import (
    QFileDialog, QHeaderView, QInputDialog, QListWidgetItem, QMessageBox,
    QSplitter, QStyle, QTableWidgetItem, QTreeWidgetItem,
)

from core.can_network import CanNetwork
from core.database_manager import DatabaseManager
from core.dbc_parser import message_can_type
from core.icons import load_icon
from ui.generated.database_widget import Ui_DatabaseWidget
from windows.base_window import BaseWindow

logger = logging.getLogger(__name__)

ROLE = Qt.ItemDataRole.UserRole
PLACEHOLDER = "..."
SEARCH_DELAY_MS = 250

_HEX_RE = re.compile(r"^0x([0-9a-fA-F]+)$")
_HEXH_RE = re.compile(r"^([0-9a-fA-F]+)h$")

C_NETWORK = ("#052c65", "#cfe2ff")
C_NODE = ("#1b5e20", "#e8f5e9")
C_TX = ("#4a148c", "#f3e5f5")
C_RX = ("#b71c1c", "#ffebee")
C_UNASSIGNED = ("#546e7a", "#eceff1")

STYLE = """
#btnAddNetwork { background:#388E3C; color:white; border-radius:3px;
                 padding:4px 12px; font-weight:bold; }
#btnAddNetwork:hover { background:#2E7D32; }
#btnLoadDbc { background:#1976D2; color:white; border-radius:3px;
              padding:3px 8px; font-weight:bold; }
#btnLoadDbc:hover { background:#1565C0; }
#btnLoadDbc:disabled { background:#bbb; color:#eee; }
"""

TREE_COLUMNS = [("Name / Message", 200), ("0xID", 68), ("DLC", 35),
                ("CAN Type", 70), ("Cycle", 58), ("Type", 72), ("Sigs", 38)]

_AL, _AC, _AR = (Qt.AlignmentFlag.AlignLeft, Qt.AlignmentFlag.AlignCenter,
                 Qt.AlignmentFlag.AlignRight)

# (tiêu đề, độ rộng, căn lề)
SIG_COLUMNS = [
    ("Name", 90, _AC), ("Message", 90, _AL), ("Mux/Group", 65, _AC),
    ("Start Bit", 58, _AC), ("Length(Bit)", 70, _AC), ("Byte Order", 80, _AC),
    ("Value Type", 62, _AC), ("Initial Value", 72, _AR), ("Factor", 58, _AR),
    ("Offset", 55, _AR), ("Min", 55, _AR), ("Max", 55, _AR), ("Unit", 50, _AC),
    ("Value Table", 90, _AL), ("Comment", 120, _AL), ("Message ID", 75, _AC),
    ("GenSigSendType", 100, _AC), ("GenSigTimeOut", 90, _AC),
]
_COL_MUX, _COL_VT = 2, 13
_CSV_SKIP = {1, 15}                    # Message, Message ID đã có ở đầu dòng CSV


# ======================================================================
# Hàm tiện ích đọc thuộc tính cantools
# ======================================================================
def fmt_frame_id(msg: Any) -> str:
    if getattr(msg, "is_extended_frame", False):
        return f"0x{msg.frame_id:08X}"
    return f"0x{msg.frame_id:03X}"


def _dbc_attr(obj: Any, name: str) -> str:
    attrs = getattr(getattr(obj, "dbc", None), "attributes", None) or {}
    v = attrs.get(name)
    return "" if v is None else str(getattr(v, "value", v))


def _s(v: Any) -> str:
    return "" if v is None else str(v)


def _value_table(sig: Any) -> str:
    choices = getattr(sig, "choices", None)
    if not choices:
        return ""
    try:
        return "; ".join(f"{k}={v}" for k, v in choices.items())
    except Exception:                                          # noqa: BLE001
        return str(choices)


def signal_values(sig: Any, msg: Any) -> list[str]:
    """18 giá trị theo thứ tự SIG_COLUMNS."""
    if getattr(sig, "is_multiplexer", False):
        mux = "MUX_IND"
    elif getattr(sig, "multiplexer_ids", None):
        mux = "M" + ",".join(str(i) for i in sig.multiplexer_ids)
    else:
        mux = ""

    byte_order = ("Big Endian" if "big" in str(getattr(sig, "byte_order", "")).lower()
                  else "Little Endian")
    if getattr(sig, "is_float", False):
        vtype = "Float" if getattr(sig, "length", 0) <= 32 else "Double"
    else:
        vtype = "Signed" if getattr(sig, "is_signed", True) else "Unsigned"

    return [
        sig.name, msg.name, mux,
        _s(getattr(sig, "start", 0)), _s(getattr(sig, "length", 0)),
        byte_order, vtype, _s(getattr(sig, "initial", None)),
        _s(getattr(sig, "scale", 1.0)), _s(getattr(sig, "offset", 0.0)),
        _s(getattr(sig, "minimum", None)), _s(getattr(sig, "maximum", None)),
        _s(getattr(sig, "unit", "")), _value_table(sig),
        _s(getattr(sig, "comment", "")), fmt_frame_id(msg),
        _dbc_attr(sig, "GenSigSendType"), _dbc_attr(sig, "GenSigTimeOut"),
    ]


# ======================================================================
# Chỉ mục tìm kiếm (tên message/signal + ID hex/thập phân)
# ======================================================================
class SearchEngine:
    def __init__(self) -> None:
        self._msgs: list[tuple[str, tuple[str, ...], Any]] = []
        self._sigs: list[tuple[str, Any]] = []

    def clear(self) -> None:
        self._msgs.clear()
        self._sigs.clear()

    @property
    def is_empty(self) -> bool:
        return not self._msgs and not self._sigs

    def add_message(self, msg: Any, item: Any) -> None:
        fid = msg.frame_id
        keys = (f"0x{fid:x}", f"{fid:x}h", str(fid))
        self._msgs.append((msg.name.lower(), keys, item))

    def add_signal(self, sig: Any, msg_item: Any) -> None:
        self._sigs.append((sig.name.lower(), msg_item))

    def search(self, query: str) -> list[Any]:
        q = query.lower().strip()
        if not q:
            return []
        is_id = bool(_HEX_RE.match(q) or _HEXH_RE.match(q) or q.isdigit())
        out: list[Any] = []
        seen: set[int] = set()

        def add(item: Any) -> None:
            if id(item) not in seen:
                seen.add(id(item))
                out.append(item)

        for name, keys, item in self._msgs:
            if (q in keys) if is_id else (q in name):
                add(item)
        if not is_id:
            for name, item in self._sigs:
                if q in name:
                    add(item)
        return out


# ======================================================================
# Cửa sổ
# ======================================================================
class DatabaseWindow(BaseWindow):
    def __init__(self, manager: DatabaseManager, parent=None):
        super().__init__(parent)
        self.ui = Ui_DatabaseWidget()
        self.ui.setupUi(self)

        self._mgr = manager
        self._tbl = getattr(self.ui, "tableSignals", None) or self.ui.tableWidget
        self._se = SearchEngine()
        self._current: str | None = None
        self._renaming = False
        self._initiated: set[str] = set()        # network do cửa sổ này yêu cầu nạp (để hiện hộp thoại lỗi)

        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(SEARCH_DELAY_MS)
        self._search_timer.timeout.connect(self._do_search)

        self._setup_ui()
        self._connect_ui()
        self._connect_manager()
        self._reload_list(select=None)
        self._update_status()

    # =========================================================
    # Dựng giao diện (phần Designer không làm được)
    # =========================================================
    def _setup_ui(self) -> None:
        ui = self.ui
        self.setStyleSheet(STYLE)
        ui.layoutNetworkDetail.setContentsMargins(8, 8, 8, 8)
        ui.layoutNetworkDetail.setSpacing(6)
        ui.groupTopology.setVisible(False)
        ui.lblTopology.setFont(QFont("Consolas", 9))
        ui.lblMessageInfo.setFont(QFont("Consolas", 9))
        ui.lblStatus.setFont(QFont("Consolas", 9))
        ui.lblStatus.setStyleSheet("color:#666;padding:1px;")

        st, SP = self.style(), QStyle.StandardPixmap
        ui.btnAddNetwork.setIcon(load_icon("add", st, SP.SP_FileDialogNewFolder))
        ui.btnRemoveNetwork.setIcon(load_icon("remove", st, SP.SP_TrashIcon))
        ui.btnExportCsv.setIcon(load_icon("export", st, SP.SP_DialogSaveButton))
        ui.btnRename.setIcon(load_icon("edit", st, SP.SP_FileDialogDetailedView))
        ui.btnBrowse.setIcon(load_icon("folder", st, SP.SP_DirOpenIcon))
        ui.btnReloadDbc.setIcon(load_icon("reload", st, SP.SP_BrowserReload))
        ui.btnClearDbc.setIcon(load_icon("close", st, SP.SP_DialogCloseButton))
        self._ic_edit = ui.btnRename.icon()
        self._ic_ok = load_icon("play", st, SP.SP_DialogApplyButton)

        t = ui.treeMessages
        t.clear()
        t.setColumnCount(len(TREE_COLUMNS))
        t.setHeaderLabels([h for h, _ in TREE_COLUMNS])
        t.setFont(QFont("Consolas", 9))
        t.setSelectionMode(t.SelectionMode.SingleSelection)
        hdr = t.header()
        hdr.setStretchLastSection(False)
        for c, (_, w) in enumerate(TREE_COLUMNS):
            hdr.setSectionResizeMode(c, QHeaderView.ResizeMode.Interactive)
            t.setColumnWidth(c, w)

        tbl = self._tbl
        tbl.setFont(QFont("Consolas", 9))
        tbl.setColumnCount(len(SIG_COLUMNS))
        tbl.setHorizontalHeaderLabels([h for h, _, _ in SIG_COLUMNS])
        sh = tbl.horizontalHeader()
        sh.setStretchLastSection(False)
        for c, (_, w, _a) in enumerate(SIG_COLUMNS):
            sh.setSectionResizeMode(c, QHeaderView.ResizeMode.Interactive)
            tbl.setColumnWidth(c, w)

        if isinstance(ui.splitterMain, QSplitter):      # chỉ có khi đã sửa Designer
            ui.splitterMain.setSizes([260, 430, 340])
            ui.splitterMain.setStretchFactor(0, 0)
            ui.splitterMain.setStretchFactor(1, 2)
            ui.splitterMain.setStretchFactor(2, 1)

    def _connect_ui(self) -> None:
        ui = self.ui
        ui.btnAddNetwork.clicked.connect(self._on_add)
        ui.btnRemoveNetwork.clicked.connect(self._on_remove)
        ui.btnExportCsv.clicked.connect(self._on_export_csv)
        ui.listNetworks.currentRowChanged.connect(self._on_net_selected)
        ui.btnRename.clicked.connect(self._toggle_rename)
        ui.editNetName.returnPressed.connect(self._confirm_rename)
        ui.editNetName.installEventFilter(self)
        ui.btnBrowse.clicked.connect(self._on_browse)
        ui.btnLoadDbc.clicked.connect(self._on_load)
        ui.btnReloadDbc.clicked.connect(self._on_reload)
        ui.btnClearDbc.clicked.connect(self._on_clear)
        ui.editSearch.textChanged.connect(self._on_search_text_changed)
        ui.chkAllNetworks.toggled.connect(self._rebuild_tree)
        ui.chkNodeView.toggled.connect(self._rebuild_tree)
        ui.treeMessages.itemClicked.connect(self._on_tree_click)
        ui.treeMessages.itemExpanded.connect(self._on_item_expanded)

    def _connect_manager(self) -> None:
        m = self._mgr
        m.networks_changed.connect(self._on_networks_changed)
        m.network_renamed.connect(self._on_network_renamed)
        m.network_updated.connect(self._on_network_updated)
        m.dbc_loading.connect(self._on_dbc_loading)
        m.dbc_loaded.connect(self._on_dbc_loaded)
        m.dbc_failed.connect(self._on_dbc_failed)
        m.dbc_cleared.connect(self._on_dbc_cleared)

    # =========================================================
    # Danh sách network
    # =========================================================
    def _current_net(self) -> CanNetwork | None:
        return self._mgr.get(self._current) if self._current else None

    def _item_style(self, net: CanNetwork) -> tuple[str, str]:
        """(hậu tố, màu chữ)."""
        if self._mgr.is_loading(net.name):
            return "  (loading...)", "#1565C0"
        if self._mgr.last_error(net.name):
            return "  (load error)", "#c62828"
        if net.is_loaded:
            return f"  [{net.message_count} msgs]", "#2e7d32"
        if net.dbc_file and not os.path.isfile(net.dbc_file):
            return "  (DBC missing)", "#b26a00"
        if net.dbc_file:
            return "  (not loaded)", "#b26a00"
        return "", ""

    def _refresh_item(self, item: QListWidgetItem, net: CanNetwork) -> None:
        tag, color = self._item_style(net)
        item.setText(f"{net.name}  (CH{net.channel_index}){tag}")
        item.setForeground(QBrush(QColor(color)) if color else QBrush())

    def _reload_list(self, select: str | None) -> None:
        lst = self.ui.listNetworks
        lst.blockSignals(True)
        lst.clear()
        row = -1
        for i, net in enumerate(self._mgr.networks.values()):
            item = QListWidgetItem()
            item.setData(ROLE, net.name)
            self._refresh_item(item, net)
            lst.addItem(item)
            if net.name == select:
                row = i
        lst.blockSignals(False)
        if row < 0 and lst.count():
            row = 0
        if row >= 0:
            lst.setCurrentRow(row)               # kích hoạt _on_net_selected
        else:
            self._current = None
            self._show_network(None)
            self._rebuild_tree()

    def _select(self, name: str) -> None:
        lst = self.ui.listNetworks
        for i in range(lst.count()):
            if lst.item(i).data(ROLE) == name:
                lst.setCurrentRow(i)
                return

    def _refresh_item_by_name(self, name: str) -> None:
        net = self._mgr.get(name)
        lst = self.ui.listNetworks
        for i in range(lst.count()):
            if lst.item(i).data(ROLE) == name and net:
                self._refresh_item(lst.item(i), net)
                return

    def _on_net_selected(self, row: int) -> None:
        item = self.ui.listNetworks.item(row) if row >= 0 else None
        self._current = item.data(ROLE) if item else None
        self._end_rename_ui()
        self._show_network(self._current_net())
        self.ui.btnRemoveNetwork.setEnabled(self._current is not None)
        self._rebuild_tree()

    def _on_add(self) -> None:
        name, ok = QInputDialog.getText(self, "Add Network", "Network name:")
        if not ok or not name.strip():
            return
        try:
            net = self._mgr.add_network(name)
        except ValueError as e:
            QMessageBox.warning(self, "Add Network", str(e))
            return
        self._select(net.name)

    def _on_remove(self) -> None:
        net = self._current_net()
        if net is None:
            return
        if QMessageBox.question(
                self, "Remove", f"Remove network '{net.name}'?"
        ) != QMessageBox.StandardButton.Yes:
            return
        self._mgr.remove_network(net.name)

    # ---------- phản ứng với manager ----------
    def _on_networks_changed(self) -> None:
        self._reload_list(select=self._current)
        self._update_status()

    def _on_network_renamed(self, old: str, new: str) -> None:
        if self._current == old:
            self._current = new
        self._reload_list(select=self._current)
        self._update_status()

    def _on_network_updated(self, name: str) -> None:
        self._refresh_item_by_name(name)
        if name == self._current:
            self._show_network(self._current_net())

    def _on_dbc_loading(self, name: str) -> None:
        self._refresh_item_by_name(name)
        if name == self._current:
            self._show_network(self._current_net())

    def _on_dbc_loaded(self, name: str, _count: int) -> None:
        self._initiated.discard(name)
        self._refresh_item_by_name(name)
        if name == self._current:
            self._show_network(self._current_net())
        self._rebuild_tree()
        self._update_status()

    def _on_dbc_failed(self, name: str, err: str) -> None:
        self._refresh_item_by_name(name)
        if name == self._current:
            self._show_network(self._current_net())
        if name in self._initiated:
            self._initiated.discard(name)
            QMessageBox.critical(self, "DBC Load Error", f"Failed:\n{err}")

    def _on_dbc_cleared(self, name: str) -> None:
        self._refresh_item_by_name(name)
        if name == self._current:
            self._show_network(self._current_net())
        self._rebuild_tree()
        self._update_status()

    # =========================================================
    # Panel chi tiết network
    # =========================================================
    def _set_net_status(self, text: str, fg: str, bg: str) -> None:
        self.ui.lblNetStatus.setText(text)
        self.ui.lblNetStatus.setStyleSheet(
            f"color:{fg};padding:4px;background:{bg};border-radius:3px;")

    def _show_network(self, net: CanNetwork | None) -> None:
        ui = self.ui
        if net is None:
            ui.editNetName.clear()
            ui.lblChannel.setText("—")
            ui.editDbcPath.clear()
            self._set_net_status("No network selected", "#666", "#f9f9f9")
            ui.groupTopology.setVisible(False)
            for b in (ui.btnBrowse, ui.btnLoadDbc, ui.btnReloadDbc,
                      ui.btnClearDbc, ui.btnRename):
                b.setEnabled(False)
            ui.btnLoadDbc.setText("Load DBC")
            return

        loading = self._mgr.is_loading(net.name)
        if not self._renaming:
            ui.editNetName.setText(net.name)
        ui.lblChannel.setText(net.get_channel_display())
        ui.editDbcPath.setText(net.dbc_file)
        ui.btnRename.setEnabled(not loading)
        ui.btnBrowse.setEnabled(not loading)
        ui.btnLoadDbc.setEnabled(bool(net.dbc_file) and not loading)
        ui.btnLoadDbc.setText("Loading..." if loading else "Load DBC")
        ui.btnReloadDbc.setEnabled(net.is_loaded and not loading)
        ui.btnClearDbc.setEnabled(net.is_loaded and not loading)

        err = self._mgr.last_error(net.name)
        if loading:
            self._set_net_status("Parsing DBC...", "#1565C0", "#e3f2fd")
        elif err:
            self._set_net_status(f"Failed: {err}", "#c62828", "#ffebee")
        elif net.is_loaded:
            self._set_net_status(
                f"Loaded: {net.message_count} msgs | {net.node_count} nodes",
                "#2e7d32", "#f1f8e9")
        else:
            self._set_net_status("No DBC loaded", "#666", "#f9f9f9")

        nodes = net.get_all_nodes()
        ui.groupTopology.setVisible(net.is_loaded and bool(nodes))
        if nodes:
            ui.lblTopology.setText(", ".join(nodes[:20]) + ("..." if len(nodes) > 20 else ""))

    # ---------- đổi tên ----------
    def _toggle_rename(self) -> None:
        if self._renaming:
            self._confirm_rename()
        elif self._current_net() is not None:
            self._start_rename()

    def _start_rename(self) -> None:
        self._renaming = True
        e = self.ui.editNetName
        e.setReadOnly(False)
        e.setStyleSheet("background:#fff9c4;border:1px solid #f9a825;")
        e.setFocus()
        e.selectAll()
        self.ui.btnRename.setIcon(self._ic_ok)

    def _end_rename_ui(self) -> None:
        self._renaming = False
        e = self.ui.editNetName
        e.setReadOnly(True)
        e.setStyleSheet("")
        self.ui.btnRename.setIcon(self._ic_edit)
        if self._current:
            e.setText(self._current)

    def _confirm_rename(self) -> None:
        if not self._renaming:
            return
        old = self._current
        new = self.ui.editNetName.text().strip()
        self._end_rename_ui()
        if not old or not new or new == old:
            return
        try:
            self._mgr.rename_network(old, new)
        except ValueError as e:
            QMessageBox.warning(self, "Rename", str(e))

    def _cancel_rename(self) -> None:
        if self._renaming:
            self._end_rename_ui()

    def eventFilter(self, obj, event):                         # noqa: N802
        if (obj is self.ui.editNetName and self._renaming
                and event.type() == QEvent.Type.KeyPress
                and event.key() == Qt.Key.Key_Escape):
            self._cancel_rename()
            return True
        return super().eventFilter(obj, event)

    # ---------- DBC ----------
    def _on_browse(self) -> None:
        net = self._current_net()
        if net is None:
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Select DBC File", os.path.dirname(net.dbc_file) if net.dbc_file else "",
            "DBC Files (*.dbc);;All Files (*)")
        if path:
            self._mgr.set_dbc_path(net.name, path)

    def _on_load(self) -> None:
        net = self._current_net()
        if net is None:
            return
        if not net.dbc_file:
            QMessageBox.warning(self, "No Path", "Browse for a DBC file first.")
            return
        if not os.path.isfile(net.dbc_file):
            QMessageBox.critical(self, "Not Found", f"File not found:\n{net.dbc_file}")
            return
        self._initiated.add(net.name)
        self._mgr.load_dbc(net.name)

    def _on_reload(self) -> None:
        self._on_load()

    def _on_clear(self) -> None:
        if net := self._current_net():
            self._mgr.clear_dbc(net.name)

    # =========================================================
    # Cây Node / Message
    # =========================================================
    def _group_item(self, label: str, colors: tuple[str, str], tag: str = "") -> QTreeWidgetItem:
        item = QTreeWidgetItem([f"{label}  {tag}".strip()] + [""] * (len(TREE_COLUMNS) - 1))
        f = item.font(0)
        f.setBold(True)
        item.setFont(0, f)
        item.setForeground(0, QBrush(QColor(colors[0])))
        item.setBackground(0, QBrush(QColor(colors[1])))
        return item

    def _msg_item(self, msg: Any) -> QTreeWidgetItem:
        ctype = message_can_type(msg)
        stype = _s(getattr(msg, "send_type", ""))
        item = QTreeWidgetItem([
            msg.name, fmt_frame_id(msg), str(msg.length), ctype,
            _s(getattr(msg, "cycle_time", "")), stype, str(len(msg.signals)),
        ])
        item.setData(0, ROLE, ("message", msg))
        if msg.signals:
            item.addChild(QTreeWidgetItem([PLACEHOLDER]))      # nạp signal khi bung (lazy)
        if ctype == "CAN FD":
            item.setForeground(3, QBrush(QColor("#0277bd")))
        if "event" in stype.lower():
            item.setForeground(5, QBrush(QColor("#664d03")))
        return item

    def _register_msg(self, msg: Any, item: QTreeWidgetItem) -> None:
        self._se.add_message(msg, item)
        for sig in msg.signals:
            self._se.add_signal(sig, item)

    def _rebuild_tree(self, *_args) -> None:
        tree = self.ui.treeMessages
        tree.clear()
        self._se.clear()

        nets = self._mgr.networks
        if self.ui.chkAllNetworks.isChecked():
            names = list(nets)
        else:
            names = [self._current] if self._current in nets else []

        node_view = self.ui.chkNodeView.isChecked()
        for name in names:
            net = nets[name]
            if not net.is_loaded:
                continue
            top = self._group_item(name, C_NETWORK, f"({net.message_count} msgs)")
            top.setData(0, ROLE, ("network", name))
            if node_view:
                self._fill_node_view(top, net)
            else:
                for msg in sorted(net.database.messages, key=lambda m: m.frame_id):
                    mi = self._msg_item(msg)
                    top.addChild(mi)
                    self._register_msg(msg, mi)
            if top.childCount():
                tree.addTopLevelItem(top)
                top.setExpanded(True)

        if self.ui.editSearch.text().strip():
            self._do_search()

    def _fill_node_view(self, top: QTreeWidgetItem, net: CanNetwork) -> None:
        placed: set[str] = set()
        for node_name in sorted(net.node_cache):
            info = net.node_cache[node_name]
            tx, rx = info.get("tx_messages", []), info.get("rx_messages", [])
            if not tx and not rx:
                continue
            node_item = self._group_item(f"Node: {node_name}", C_NODE,
                                         f"(TX:{len(tx)}  RX:{len(rx)})")
            for label, colors, msgs in (("TX Messages", C_TX, tx), ("RX Messages", C_RX, rx)):
                if not msgs:
                    continue
                group = self._group_item(label, colors, f"({len(msgs)})")
                for msg in sorted(msgs, key=lambda m: m.frame_id):
                    mi = self._msg_item(msg)
                    group.addChild(mi)
                    placed.add(msg.name)
                    self._register_msg(msg, mi)
                node_item.addChild(group)
                group.setExpanded(True)
            top.addChild(node_item)
            node_item.setExpanded(True)

        rest = [m for m in sorted(net.database.messages, key=lambda m: m.frame_id)
                if m.name not in placed]
        if rest:
            group = self._group_item("Unassigned", C_UNASSIGNED, f"({len(rest)})")
            for msg in rest:
                mi = self._msg_item(msg)
                group.addChild(mi)
                self._register_msg(msg, mi)
            top.addChild(group)

    def _on_item_expanded(self, item: QTreeWidgetItem) -> None:
        if item.childCount() != 1 or item.child(0).text(0) != PLACEHOLDER:
            return
        data = item.data(0, ROLE)
        if not data or data[0] != "message":
            return
        item.takeChild(0)
        for sig in data[1].signals:
            si = QTreeWidgetItem([sig.name] + [""] * (len(TREE_COLUMNS) - 1))
            si.setData(0, ROLE, ("signal", sig))
            si.setForeground(0, QBrush(QColor("#0d47a1")))
            item.addChild(si)

    def _on_tree_click(self, item: QTreeWidgetItem, _col: int) -> None:
        data = item.data(0, ROLE)
        if not data:
            return
        if data[0] == "message":
            self._show_message(data[1])
        elif data[0] == "signal" and item.parent():
            pd = item.parent().data(0, ROLE)
            if pd and pd[0] == "message":
                self._show_message(pd[1])

    # =========================================================
    # Chi tiết message + bảng signal
    # =========================================================
    def _show_message(self, msg: Any) -> None:
        lines = [
            f"{'Name':<10}: {msg.name}",
            f"{'Frame ID':<10}: {fmt_frame_id(msg)}  ({msg.frame_id})"
            + (" (Extended)" if getattr(msg, "is_extended_frame", False) else ""),
            f"{'CAN Type':<10}: {message_can_type(msg)}",
            f"{'DLC':<10}: {msg.length} bytes",
        ]
        for attr, label in (("cycle_time", "Cycle"), ("send_type", "SendType"),
                            ("senders", "Senders"), ("comment", "Comment")):
            v = getattr(msg, attr, None)
            if v:
                lines.append(f"{label:<10}: {', '.join(v) if isinstance(v, list) else v}")
        self.ui.lblMessageInfo.setText("\n".join(lines))

        tbl = self._tbl
        tbl.setUpdatesEnabled(False)
        try:
            tbl.setRowCount(0)
            tbl.setRowCount(len(msg.signals))
            for r, sig in enumerate(msg.signals):
                values = signal_values(sig, msg)
                mux = values[_COL_MUX]
                bg = (QBrush(QColor("#fff9c4")) if mux == "MUX_IND"
                      else QBrush(QColor("#e8f5e9")) if mux else None)
                for c, txt in enumerate(values):
                    it = QTableWidgetItem(txt)
                    it.setTextAlignment(SIG_COLUMNS[c][2] | Qt.AlignmentFlag.AlignVCenter)
                    if bg:
                        it.setBackground(bg)
                    if c == _COL_VT and txt:
                        it.setToolTip(txt.replace("; ", "\n"))
                    tbl.setItem(r, c, it)
        finally:
            tbl.setUpdatesEnabled(True)
        tbl.resizeRowsToContents()

    # =========================================================
    # Tìm kiếm
    # =========================================================
    def _on_search_text_changed(self, text: str) -> None:
        self._search_timer.stop()
        if not text.strip():
            self.ui.editSearch.setStyleSheet("")
            self._reset_visibility()
            return
        self._search_timer.start()

    def _do_search(self) -> None:
        query = self.ui.editSearch.text().strip()
        if not query or self._se.is_empty:
            self._reset_visibility()
            return
        matches = self._se.search(query)
        if not matches:
            self._reset_visibility()
            self.ui.editSearch.setStyleSheet(
                "QLineEdit{background:#ffebee;border:1px solid #ef9a9a;}")
            return
        self.ui.editSearch.setStyleSheet("")

        tree = self.ui.treeMessages
        stack = [tree.topLevelItem(i) for i in range(tree.topLevelItemCount())]
        while stack:                                   # ẩn mọi thứ dưới cấp network
            it = stack.pop()
            for j in range(it.childCount()):
                child = it.child(j)
                child.setHidden(True)
                stack.append(child)

        for item in matches:
            cur = item
            while cur is not None:                     # hiện item + toàn bộ cha
                cur.setHidden(False)
                tree.expandItem(cur)
                cur = cur.parent()
            for j in range(item.childCount()):         # hiện signal con của message
                item.child(j).setHidden(False)

        tree.scrollToItem(matches[0])
        tree.setCurrentItem(matches[0])

    def _reset_visibility(self) -> None:
        tree = self.ui.treeMessages
        stack = [tree.topLevelItem(i) for i in range(tree.topLevelItemCount())]
        while stack:
            it = stack.pop()
            it.setHidden(False)
            stack.extend(it.child(j) for j in range(it.childCount()))

    # =========================================================
    # Xuất CSV
    # =========================================================
    def _on_export_csv(self) -> None:
        loaded = [(n, net) for n, net in self._mgr.networks.items() if net.is_loaded]
        if not loaded:
            QMessageBox.information(self, "Empty", "No DBC loaded.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Signal List", "signals.csv", "CSV (*.csv)")
        if not path:
            return
        header = (["Network", "Message", "Message_ID", "DLC", "CycleTime", "SendType"]
                  + [h.replace(" ", "_") for i, (h, _w, _a) in enumerate(SIG_COLUMNS)
                     if i not in _CSV_SKIP])
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                w = csv.writer(fh)
                w.writerow(header)
                for net_name, net in loaded:
                    for msg in sorted(net.database.messages, key=lambda m: m.frame_id):
                        head = [net_name, msg.name, fmt_frame_id(msg), msg.length,
                                _s(getattr(msg, "cycle_time", "")),
                                _s(getattr(msg, "send_type", ""))]
                        for sig in msg.signals:
                            vals = signal_values(sig, msg)
                            w.writerow(head + [v for i, v in enumerate(vals)
                                               if i not in _CSV_SKIP])
            self.ui.lblStatus.setText(f"Exported: {path}")
        except OSError as e:
            QMessageBox.critical(self, "Export Error", str(e))

    # =========================================================
    # Trạng thái
    # =========================================================
    def _update_status(self) -> None:
        nets = self._mgr.networks.values()
        loaded = [n for n in nets if n.is_loaded]
        self.ui.lblStatus.setText(
            f"Networks: {len(nets)}  |  DBC loaded: {len(loaded)}  |  "
            f"Messages: {sum(n.message_count for n in loaded)}")