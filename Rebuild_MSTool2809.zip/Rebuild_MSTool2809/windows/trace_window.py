"""TraceWindow: cửa sổ Trace kiểu TSMaster / CANoe, chế độ Fixed (mỗi (Chn, ID) một dòng)."""
from __future__ import annotations

import csv
import time
from dataclasses import dataclass
from pathlib import Path

from PyQt6.QtCore import QSettings, Qt, QTimer, pyqtSignal, pyqtSlot
from PyQt6.QtGui import QActionGroup, QBrush, QColor, QIcon
from PyQt6.QtWidgets import (
    QAbstractItemView, QFileDialog, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMenu, QMessageBox, QStyle, QToolButton, QTreeWidgetItem, QWidget, QWidgetAction,
)

from core.trace_types import (
    COL_BRS, COL_BYTE0, COL_CHN, COL_CNT, COL_DA, COL_DATALEN, COL_DIR, COL_DLC,
    COL_ESI, COL_FPS, COL_FUNC, COL_ID, COL_NAME, COL_NODEID, COL_PGN, COL_PRIO,
    COL_SA, COL_TIME, COL_TYPE, HEADERS, NCOLS, PROTOCOL_SPECS,
    CanFrame, DecodedMessage, Decoder, Protocol,
    accepts, fmt_id, fmt_time, parse_canopen, parse_j1939, visible_columns,
)
from ui.generated.trace_widget import Ui_TraceWidget
from windows.base_window import BaseWindow

ICON_DIR = Path(__file__).resolve().parent.parent / "resources" / "icons"

_DEFAULT_WIDTHS = {
    COL_TIME: 160, COL_CNT: 70, COL_CHN: 50, COL_ID: 90, COL_FPS: 50,
    COL_NAME: 190, COL_TYPE: 80, COL_DIR: 40, COL_DLC: 40, COL_DATALEN: 70,
    COL_BRS: 40, COL_ESI: 40, COL_PRIO: 60, COL_PGN: 70, COL_SA: 45,
    COL_DA: 45, COL_NODEID: 65, COL_FUNC: 70,
}
_CENTER = int(Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter)


@dataclass(slots=True, eq=False)
class _Row:
    key: tuple[int, int]
    frame: CanFrame
    count: int = 0
    fps_count: int = 0
    fps: int = 0
    last_seen: float = 0.0
    item: QTreeWidgetItem | None = None
    name: str = ""
    decode_tried: bool = False
    decoded: DecodedMessage | None = None
    decoded_data: bytes = b""
    stale: bool = False


class TraceWindow(BaseWindow):
    protocolChanged = pyqtSignal(object)          # phát Protocol mới

    ORG, APP = "MS_Tool", "TraceWindow"
    MAX_ROWS = 5000                               # trần số dòng (progressBuffer hiển thị % lấp đầy)
    STALE_AFTER_S = 1.0
    REFRESH_CHOICES_MS = (50, 100, 200, 500, 1000)
    DEFAULT_REFRESH_MS = 100

    def __init__(self, parent=None, decoder: Decoder | None = None,
                 settings: QSettings | None = None):
        super().__init__(parent)
        self.ui = Ui_TraceWidget()
        self.ui.setupUi(self)

        self._decoder = decoder
        self._settings = settings or QSettings(self.ORG, self.APP)
        self._protocol = Protocol.CAN
        self._refresh_ms = self.DEFAULT_REFRESH_MS
        self._rows: dict[tuple[int, int], _Row] = {}
        self._dirty: set[tuple[int, int]] = set()
        self._all_count = 0
        self._in_list = 0
        self._paused = False
        self._filter_text = ""
        self._visible: list[int] = []
        self._max_bytes = 8
        self._last_fps_tick = time.monotonic()
        self._gray = QBrush(QColor(150, 150, 150))
        self._normal = QBrush()                   # brush rỗng = màu mặc định của palette

        self._setup_tree()
        self._setup_icons()
        self._build_settings_menu()
        self._setup_timers()
        self._connect_signals()
        self._apply_protocol_columns()
        self.load_configuration()
        self._update_status()

    # =========================================================
    # API công khai
    # =========================================================
    @pyqtSlot(object)
    def on_frame(self, frame: CanFrame) -> None:
        """Nối với pyqtSignal(object) của nguồn CAN. Chỉ gộp dữ liệu, không vẽ."""
        if not accepts(self._protocol, frame):
            return
        self._all_count += 1
        key = (frame.channel, frame.can_id)
        row = self._rows.get(key)
        if row is None:
            if len(self._rows) >= self.MAX_ROWS:
                return
            row = _Row(key=key, frame=frame)
            self._rows[key] = row
        row.frame = frame
        row.count += 1
        row.fps_count += 1
        row.last_seen = time.monotonic()
        self._dirty.add(key)

    @property
    def protocol(self) -> Protocol:
        return self._protocol

    @property
    def sync_token(self) -> str:
        return self.editSyncToken.text()

    def set_decoder(self, decoder: Decoder | None) -> None:
        self._decoder = decoder
        for row in self._rows.values():
            row.decode_tried = False
            row.decoded = None
            row.name = ""
        self._dirty.update(self._rows)

    @pyqtSlot()
    def refresh_decoder(self) -> None:
        self.set_decoder(self._decoder)

    def set_protocol(self, protocol: Protocol) -> None:
        if protocol is self._protocol:
            return
        self._protocol = protocol
        self._proto_actions[protocol].setChecked(True)
        self.clear()
        self._apply_protocol_columns()
        self.protocolChanged.emit(protocol)

    def set_refresh_ms(self, ms: int) -> None:
        self._refresh_ms = ms
        self._refresh_timer.setInterval(ms)
        if ms in self._refresh_actions:
            self._refresh_actions[ms].setChecked(True)

    def clear(self) -> None:
        self.ui.treeTrace.clear()
        self._rows.clear()
        self._dirty.clear()
        self._all_count = 0
        self._in_list = 0
        self._update_status()

    def expand_all(self) -> None:
        self.ui.treeTrace.expandAll()
        for row in self._rows.values():
            self._refresh_children(row)

    # =========================================================
    # Dựng giao diện (phần Designer không làm được)
    # =========================================================
    def _setup_tree(self) -> None:
        t = self.ui.treeTrace
        t.clear()                                 # bỏ item mẫu còn sót từ Designer
        t.setColumnCount(NCOLS)
        t.setHeaderLabels(HEADERS)
        t.setRootIsDecorated(True)
        t.setUniformRowHeights(True)
        t.setAlternatingRowColors(True)
        t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        t.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        hdr = t.header()
        hdr.setStretchLastSection(False)
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        for c in range(NCOLS):
            t.setColumnWidth(c, _DEFAULT_WIDTHS.get(c, 32))

    def _icon(self, name: str, fallback: QStyle.StandardPixmap) -> QIcon:
        path = ICON_DIR / f"{name}.svg"
        if path.exists():
            icon = QIcon(str(path))
            if not icon.isNull():
                return icon
        return self.style().standardIcon(fallback)

    def _setup_icons(self) -> None:
        ui, SP = self.ui, QStyle.StandardPixmap
        self._ic_pause = self._icon("pause", SP.SP_MediaPause)
        self._ic_resume = self._icon("play", SP.SP_MediaPlay)
        ui.btnPause.setIcon(self._ic_pause)
        ui.btnSave.setIcon(self._icon("save", SP.SP_DialogSaveButton))
        ui.btnClear.setIcon(self._icon("clear", SP.SP_TrashIcon))
        ui.btnAutoScroll.setIcon(self._icon("autoscroll", SP.SP_ArrowDown))
        ui.btnExpandAll.setIcon(self._icon("expand", SP.SP_TitleBarUnshadeButton))
        ui.btnCollapseAll.setIcon(self._icon("collapse", SP.SP_TitleBarShadeButton))
        ui.btnSnapshot.setIcon(self._icon("snapshot", SP.SP_DesktopIcon))
        ui.btnSettings.setIcon(self._icon("settings", SP.SP_FileDialogContentsView))
        funnel = self._icon("filter", SP.SP_FileDialogDetailedView)
        ui.lblFilterIcon.setPixmap(funnel.pixmap(16, 16))

    def _build_settings_menu(self) -> None:
        m = QMenu(self.ui.btnSettings)

        m.addAction("Export Message List...").setEnabled(False)
        m.addAction("Import Message List...").setEnabled(False)
        m.addSeparator()

        # Protocol: chọn một
        pm = m.addMenu("Protocol")
        pgroup = QActionGroup(self)
        pgroup.setExclusive(True)
        self._proto_actions = {}
        for p in Protocol:
            act = pm.addAction(p.value)
            act.setCheckable(True)
            pgroup.addAction(act)
            act.triggered.connect(lambda _c, p=p: self.set_protocol(p))
            self._proto_actions[p] = act
        self._proto_actions[self._protocol].setChecked(True)

        # Refresh Rate: chọn một
        rm = m.addMenu("Refresh Rate")
        rgroup = QActionGroup(self)
        rgroup.setExclusive(True)
        self._refresh_actions = {}
        for ms in self.REFRESH_CHOICES_MS:
            act = rm.addAction(f"{ms} ms")
            act.setCheckable(True)
            rgroup.addAction(act)
            act.triggered.connect(lambda _c, ms=ms: self.set_refresh_ms(ms))
            self._refresh_actions[ms] = act
        self._refresh_actions[self._refresh_ms].setChecked(True)

        m.addAction("Save Default Configuration", self.save_configuration)

        # Sync. Token: QLineEdit nằm trong menu
        box = QWidget(m)
        lay = QHBoxLayout(box)
        lay.setContentsMargins(12, 4, 12, 4)
        lay.addWidget(QLabel("Sync. Token:"))
        self.editSyncToken = QLineEdit()
        self.editSyncToken.setMinimumWidth(140)
        lay.addWidget(self.editSyncToken)
        wa = QWidgetAction(m)
        wa.setDefaultWidget(box)
        m.addAction(wa)

        m.addAction("Snapshot Configuration...").setEnabled(False)

        self.ui.btnSettings.setMenu(m)
        self.ui.btnSettings.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)

    def _setup_timers(self) -> None:
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(self._refresh_ms)
        self._refresh_timer.timeout.connect(self._on_refresh)
        self._refresh_timer.start()

        self._fps_timer = QTimer(self)
        self._fps_timer.setInterval(1000)
        self._fps_timer.timeout.connect(self._on_fps_tick)
        self._fps_timer.start()

        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(150)
        self._filter_timer.timeout.connect(self.apply_filter)

    def _connect_signals(self) -> None:
        ui = self.ui
        ui.btnPause.toggled.connect(self._on_pause_toggled)
        ui.btnSave.clicked.connect(self.save_csv)
        ui.btnClear.clicked.connect(self.clear)
        ui.btnExpandAll.clicked.connect(self.expand_all)
        ui.btnCollapseAll.clicked.connect(ui.treeTrace.collapseAll)
        ui.btnSnapshot.clicked.connect(self.save_snapshot)
        ui.editFilter.textChanged.connect(lambda _t: self._filter_timer.start())
        ui.treeTrace.itemExpanded.connect(self._on_item_expanded)

    # =========================================================
    # Protocol -> ẩn/hiện cột (không tạo lại form)
    # =========================================================
    def _apply_protocol_columns(self) -> None:
        spec = PROTOCOL_SPECS[self._protocol]
        vis = visible_columns(self._protocol)
        self._visible = sorted(vis)
        self._max_bytes = spec.max_bytes
        t = self.ui.treeTrace
        for c in range(NCOLS):
            t.setColumnHidden(c, c not in vis)
        t.headerItem().setText(COL_ID, spec.id_header)

    # =========================================================
    # Vẽ theo chu kỳ
    # =========================================================
    def _on_pause_toggled(self, checked: bool) -> None:
        self._paused = checked
        self.ui.btnPause.setIcon(self._ic_resume if checked else self._ic_pause)
        if not checked:
            self._on_refresh()                    # vẽ bù những gì đã gộp trong lúc pause

    def _on_refresh(self) -> None:
        if self._paused:
            return
        added = False
        if self._dirty:
            t = self.ui.treeTrace
            t.setUpdatesEnabled(False)
            try:
                for key in self._dirty:
                    row = self._rows.get(key)
                    if row is None:
                        continue
                    if row.item is None:
                        self._create_item(row)
                        added = True
                    self._paint_row(row)
                self._dirty.clear()
            finally:
                t.setUpdatesEnabled(True)
            if added and self.ui.btnAutoScroll.isChecked():
                t.scrollToBottom()
        self._update_status()

    def _create_item(self, row: _Row) -> None:
        item = QTreeWidgetItem(self.ui.treeTrace)
        item.setData(0, Qt.ItemDataRole.UserRole, row.key)
        for c in range(COL_CNT, NCOLS):
            if c != COL_NAME:
                item.setTextAlignment(c, _CENTER)
        item.setText(COL_CHN, str(row.frame.channel))
        item.setText(COL_ID, fmt_id(row.frame))
        item.setText(COL_FPS, "0")
        row.item = item
        self._in_list += 1

    def _paint_row(self, row: _Row) -> None:
        item, f = row.item, row.frame

        if self._decoder is not None:
            expanded = item.isExpanded()
            need = (not row.decode_tried) or (
                row.decoded is not None and expanded and row.decoded_data != f.data)
            if need:
                self._decode(row)

        set_text = item.setText
        set_text(COL_TIME, fmt_time(f.timestamp))
        set_text(COL_CNT, str(row.count))
        set_text(COL_NAME, row.name)
        set_text(COL_TYPE, f.type_label)
        set_text(COL_DIR, f.direction)
        set_text(COL_DLC, str(f.dlc))

        p = self._protocol
        if p is Protocol.CAN_FD:
            set_text(COL_DATALEN, str(f.length))
            set_text(COL_BRS, ("1" if f.brs else "0") if f.is_fd else "")
            set_text(COL_ESI, ("1" if f.esi else "0") if f.is_fd else "")
        elif p is Protocol.J1939:
            prio, pgn, sa, da = parse_j1939(f.can_id)
            set_text(COL_PRIO, str(prio))
            set_text(COL_PGN, f"{pgn:X}")
            set_text(COL_SA, f"{sa:02X}")
            set_text(COL_DA, f"{da:02X}")
        elif p is Protocol.CANOPEN:
            func, node = parse_canopen(f.can_id)
            set_text(COL_FUNC, func)
            set_text(COL_NODEID, node)

        data = f.data
        n = len(data)
        for i in range(self._max_bytes):
            set_text(COL_BYTE0 + i, f"{data[i]:02X}" if i < n else "")

        if row.stale:
            row.stale = False
            self._set_row_color(row, gray=False)
        self._apply_filter_row(row)

    def _on_fps_tick(self) -> None:
        now = time.monotonic()
        dt = max(now - self._last_fps_tick, 1e-3)
        self._last_fps_tick = now
        for row in self._rows.values():
            row.fps = round(row.fps_count / dt)
            row.fps_count = 0
            if row.item is None or self._paused:
                continue
            row.item.setText(COL_FPS, str(row.fps))
            if not row.stale and (now - row.last_seen) > self.STALE_AFTER_S:
                row.stale = True
                self._set_row_color(row, gray=True)

    def _set_row_color(self, row: _Row, gray: bool) -> None:
        brush = self._gray if gray else self._normal
        item = row.item
        for c in self._visible:
            item.setForeground(c, brush)
        for i in range(item.childCount()):
            child = item.child(i)
            child.setForeground(COL_TIME, brush)
            child.setForeground(COL_NAME, brush)

    def _update_status(self) -> None:
        ui = self.ui
        ui.lblInList.setText(f"In list: {self._in_list}")
        ui.lblAllCount.setText(f"All count: {self._all_count:,}")
        ui.progressBuffer.setValue(min(100, round(len(self._rows) * 100 / self.MAX_ROWS)))

    # =========================================================
    # Signal con (decoder)
    # =========================================================
    def _decode(self, row: _Row) -> None:
        row.decode_tried = True
        row.decoded_data = row.frame.data
        try:
            row.decoded = self._decoder(row.frame.can_id, row.frame.data)
        except Exception:
            row.decoded = None
        row.name = row.decoded.name if row.decoded else ""
        self._sync_children(row)

    def _sync_children(self, row: _Row) -> None:
        item = row.item
        sigs = list(row.decoded.signals.items()) if row.decoded else []
        if item.childCount() != len(sigs):
            item.takeChildren()
            for name, val in sigs:
                child = QTreeWidgetItem(item)
                child.setText(COL_TIME, name)
                child.setText(COL_NAME, val)
        else:
            for i, (name, val) in enumerate(sigs):
                child = item.child(i)
                if child.text(COL_TIME) != name:
                    child.setText(COL_TIME, name)
                child.setText(COL_NAME, val)

    def _refresh_children(self, row: _Row) -> None:
        if row.item is None or self._decoder is None:
            return
        if row.decoded is not None and row.decoded_data != row.frame.data:
            self._decode(row)
        else:
            self._sync_children(row)

    def _on_item_expanded(self, item: QTreeWidgetItem) -> None:
        key = item.data(0, Qt.ItemDataRole.UserRole)
        row = self._rows.get(key) if key is not None else None
        if row is not None:
            self._refresh_children(row)

    # =========================================================
    # Lọc
    # =========================================================
    def apply_filter(self) -> None:
        self._filter_text = self.ui.editFilter.text().strip().lower()
        t = self.ui.treeTrace
        t.setUpdatesEnabled(False)
        try:
            for row in self._rows.values():
                if row.item is not None:
                    self._apply_filter_row(row)
        finally:
            t.setUpdatesEnabled(True)
        self._update_status()

    def _matches(self, row: _Row) -> bool:
        t = self._filter_text
        if not t:
            return True
        cid = row.frame.can_id
        return t in row.name.lower() or t in f"{cid:x}" or t in f"0x{cid:x}"

    def _apply_filter_row(self, row: _Row) -> None:
        hidden = not self._matches(row)
        if hidden != row.item.isHidden():
            row.item.setHidden(hidden)
            self._in_list += -1 if hidden else 1

    # =========================================================
    # Lưu CSV / Snapshot
    # =========================================================
    def save_csv(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Trace", f"trace_{time.strftime('%Y%m%d_%H%M%S')}.csv",
            "CSV files (*.csv)")
        if not path:
            return
        for row in self._rows.values():
            self._refresh_children(row)
        cols = self._visible
        t = self.ui.treeTrace
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                w = csv.writer(fh)
                w.writerow([t.headerItem().text(c) for c in cols] + ["Signal", "Value"])
                for i in range(t.topLevelItemCount()):
                    it = t.topLevelItem(i)
                    if it.isHidden():
                        continue
                    w.writerow([it.text(c) for c in cols] + ["", ""])
                    for j in range(it.childCount()):
                        ch = it.child(j)
                        w.writerow([""] * len(cols) + [ch.text(COL_TIME), ch.text(COL_NAME)])
        except OSError as e:
            QMessageBox.critical(self, "Save Trace", str(e))

    def save_snapshot(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Snapshot", f"trace_{time.strftime('%Y%m%d_%H%M%S')}.png",
            "PNG image (*.png)")
        if path and not self.ui.treeTrace.grab().save(path, "PNG"):
            QMessageBox.critical(self, "Snapshot", f"Cannot write {path}")

    # =========================================================
    # Cấu hình (QSettings)
    # =========================================================
    def save_configuration(self) -> None:
        s = self._settings
        s.beginGroup("trace")
        s.setValue("protocol", self._protocol.value)
        s.setValue("refresh_ms", self._refresh_ms)
        s.setValue("auto_scroll", self.ui.btnAutoScroll.isChecked())
        s.setValue("filter", self.ui.editFilter.text())
        s.setValue("sync_token", self.editSyncToken.text())
        s.setValue("header_state", self.ui.treeTrace.header().saveState())
        s.endGroup()
        s.sync()

    def load_configuration(self) -> None:
        s = self._settings
        s.beginGroup("trace")
        name = s.value("protocol", Protocol.CAN.value, type=str)
        ms = s.value("refresh_ms", self.DEFAULT_REFRESH_MS, type=int)
        auto = s.value("auto_scroll", True, type=bool)
        text = s.value("filter", "", type=str)
        token = s.value("sync_token", "", type=str)
        state = s.value("header_state")
        s.endGroup()

        self._protocol = next((p for p in Protocol if p.value == name), Protocol.CAN)
        self._proto_actions[self._protocol].setChecked(True)
        self.set_refresh_ms(ms if ms in self.REFRESH_CHOICES_MS else self.DEFAULT_REFRESH_MS)
        self.ui.btnAutoScroll.setChecked(auto)
        self.ui.editFilter.setText(text)
        self.editSyncToken.setText(token)
        if state:
            self.ui.treeTrace.header().restoreState(state)
        self._apply_protocol_columns()            # áp lại ẩn/hiện cột sau khi restoreState