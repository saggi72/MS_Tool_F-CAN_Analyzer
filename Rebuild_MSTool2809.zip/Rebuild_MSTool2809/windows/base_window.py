from PyQt6.QtWidgets import QWidget


class BaseWindow(QWidget):
    """Lớp cha của mọi cửa sổ chức năng trong MDI.

    Không tạo layout: layout do file .ui của từng cửa sổ quyết định.
    Chỗ này để thêm hàm dùng chung sau này (lưu/khôi phục trạng thái...).
    """