import logging
import queue

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import QDockWidget, QLabel, QMainWindow

from core import system_log
from core.database_manager import DatabaseManager
from core.frame_pump import FramePump
from core.hardware import QUEUE_MAXSIZE, HardwareManager
from core.measurement_session import MeasurementSession
from core.window_registry import WindowRegistry, WindowSpec
from core.workspace_manager import WorkspaceManager
from models.hw_settings import HwSettingsStore
from ui.dialogs.channel_mapping_dialog import ChannelMappingDialog
from ui.dialogs.hardware_config_dialog import HardwareConfigDialog
from ui.generated.MainWindow import Ui_MainWindow
from ui.widgets.system_message_widget import SystemMessageWidget
from windows.database_window import DatabaseWindow
from windows.trace_window import TraceWindow

logger = logging.getLogger(__name__)

# Action (checkable) in MainWindow.ui that shows/hides the System Messages dock.
# Add it in Designer (e.g. in menuHome); until it exists the dock is simply always available.
SYSTEM_MESSAGES_ACTION = "actionHomeSystemMessages"


class MainWindow(QMainWindow):
    """Vỏ ứng dụng: nạp giao diện từ pyuic6 và nối logic Python vào."""

    frame_received = pyqtSignal(object)      # bus nội bộ: nguồn CAN thật sẽ phát vào đây

    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self._setup_system_messages()            # SỚM NHẤT, trước các manager

        self.hw_store = HwSettingsStore(self)

        self.database = DatabaseManager(self)
        # keep hardware mapping when a network is renamed (mapping is keyed by network name)
        self.database.network_renamed.connect(self.hw_store.rename_network)

        # hardware: one shared RX queue, one HardwareManager, one Start/Stop session
        self.rx_queue = queue.Queue(maxsize=QUEUE_MAXSIZE)
        self.hw_manager = HardwareManager(self.rx_queue, parent=self)
        self.session = MeasurementSession(self.hw_store, self.database, self.hw_manager, self)

        # RX bridge: rx_queue -> (convert) -> frame_received -> Trace / Graphic ...
        self.pump = FramePump(self.hw_manager, self.database, parent=self)
        self.pump.frame_ready.connect(self.frame_received)
        self.session.running_changed.connect(self.pump.set_running)
        self.database.networks_changed.connect(self.pump.invalidate)
        self.database.network_renamed.connect(lambda *_: self.pump.invalidate())
        self.workspaces = WorkspaceManager(self.ui.workspaceTabs, self)
        self.registry = WindowRegistry(self.workspaces, self)

        self._register_windows()
        self._connect_actions()
        self._setup_run_controls()

        logger.info("MS_Tool ready")

    # ---------- system messages ----------
    def _setup_system_messages(self):
        self.system_log = system_log.install()
        self.sysMsgWidget = SystemMessageWidget()
        self.system_log.message.connect(self.sysMsgWidget.append_message)

        dock = QDockWidget("System Messages", self)
        dock.setObjectName("dockSystemMessages")     # cần để saveState sau này
        dock.setWidget(self.sysMsgWidget)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock)
        self.dockSystemMessages = dock

        act = getattr(self.ui, SYSTEM_MESSAGES_ACTION, None)
        if act is not None:
            act.setCheckable(True)
            act.setChecked(True)
            act.toggled.connect(dock.setVisible)
            dock.visibilityChanged.connect(act.setChecked)   # bấm X trên dock thì nút cũng bỏ tick

    # ---------- đăng ký cửa sổ ----------
    def _register_windows(self):
        reg = self.registry
        reg.register("actionBusTrace",
                     WindowSpec("trace", "Trace", self._make_trace, (1000, 600)))
        reg.register("actionAdd_CAN_Database",
                     WindowSpec("can_database", "CAN Database", self._make_database, (1100, 650)))
        reg.bind(self.ui)

    def _make_trace(self) -> TraceWindow:
        win = TraceWindow(decoder=self.database.trace_decoder)
        self.frame_received.connect(win.on_frame)
        self.database.decoders_changed.connect(win.refresh_decoder)
        return win

    def _make_database(self) -> DatabaseWindow:
        return DatabaseWindow(self.database)

    # ---------- hardware dialogs ----------
    def _open_hw_config(self):
        HardwareConfigDialog(self.hw_store, hw_manager=self.hw_manager, parent=self).exec()

    def _networks_for_mapping(self):
        """[(net_name, 'CH1'), ...] — mọi network trong database (kể cả chưa nạp DBC)."""
        nets = sorted(self.database.networks.values(),
                      key=lambda n: n.channel_index or 0)
        return [(n.name, f"CH{n.channel_index}" if n.channel_index else "")
                for n in nets]

    def _open_channel_mapping(self):
        ChannelMappingDialog(
            self.hw_store,
            networks_provider=self._networks_for_mapping,
            running=self.session.is_running,
            parent=self,
        ).exec()

    # ---------- Start / Stop ----------
    def _setup_run_controls(self):
        ui = self.ui
        self.lblRunState = QLabel()
        ui.statusbar.addPermanentWidget(self.lblRunState)

        ui.actionHomeStart.triggered.connect(lambda _checked=False: self.session.start())
        ui.actionHomeStop.triggered.connect(lambda _checked=False: self.session.stop())
        self.session.running_changed.connect(self._on_running_changed)
        self._on_running_changed(False)

    def _on_running_changed(self, running: bool):
        self.ui.actionHomeStart.setEnabled(not running)
        self.ui.actionHomeStop.setEnabled(running)
        self.lblRunState.setText("●  Running" if running else "■  Stopped")
        self.lblRunState.setStyleSheet(
            "padding:0 8px;font-weight:bold;color:#2e7d32;" if running
            else "padding:0 8px;color:#666;")

    # ---------- action ----------
    def _connect_actions(self):
        ui = self.ui
        ui.actionFileExit.triggered.connect(self.close)
        ui.actionLayoutCascade.triggered.connect(self.workspaces.cascade)
        ui.actionLayoutTile.triggered.connect(self.workspaces.tile)
        ui.actionLayoutMinimizeAll.triggered.connect(self.workspaces.minimize_all)
        ui.actionHardwareConfiguration.triggered.connect(self._open_hw_config)
        ui.actionHardwareChannelMapping.triggered.connect(self._open_channel_mapping)

        # Action chưa có chức năng: báo [TODO] ở status bar
        handled = {
            "actionFileExit", "actionLayoutCascade",
            "actionLayoutTile", "actionLayoutMinimizeAll",
            "actionHardwareConfiguration", "actionHardwareChannelMapping",
            "actionHomeStart", "actionHomeStop",
            SYSTEM_MESSAGES_ACTION,
        } | self.registry.registered_actions()

        for action in self.findChildren(QAction):
            name = action.objectName()
            if name.startswith("action") and name not in handled:
                action.triggered.connect(
                    lambda _checked=False, n=name:
                        self.ui.statusbar.showMessage(f"[TODO] {n}", 3000))

    def closeEvent(self, event):
        self.session.stop()                  # đóng bus trước khi thoát
        self.database.shutdown()
        system_log.uninstall()
        super().closeEvent(event)