"""
ui/widgets/system_message_widget.py
System Messages — shows the log of the WHOLE application.

Source of messages: core.system_log (python `logging` -> Qt signal).
This widget never talks to HardwareManager / dialogs directly; anything
that calls logger.info/warning/error(...) shows up here.

Generated UI: ui/generated/SystemMessageWidget.py   (class Ui_SystemMessageWidget)
    pyuic6 ui/designer/SystemMessageWidget.ui -o ui/generated/SystemMessageWidget.py

Wiring (MainWindow):
    from core import system_log
    self.system_log = system_log.install()
    self.sysMsgWidget = SystemMessageWidget(self)
    self.system_log.message.connect(self.sysMsgWidget.append_message)
"""

from __future__ import annotations

from collections import deque
from datetime import datetime
from typing import Deque, Tuple

from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QHeaderView, QTableWidgetItem, QWidget

from ui.generated.SystemMessageWidget import Ui_SystemMessageWidget   # <- adjust to your file name

MAX_ROWS = 5000          # oldest rows are dropped beyond this
TRIM_CHUNK = 250         # drop in chunks, not one row per message
FLUSH_MS = 100           # batch UI updates (bursts of errors won't freeze the GUI)

LEVEL_COLORS = {
    "DEBUG":    QColor("#808080"),
    "WARNING":  QColor("#b26a00"),
    "ERROR":    QColor("#c62828"),
    "CRITICAL": QColor("#c62828"),
}


class SystemMessageWidget(QWidget):

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.ui = Ui_SystemMessageWidget()
        self.ui.setupUi(self)

        self._pending: Deque[Tuple[float, str, str, str]] = deque()
        self._timer = QTimer(self)
        self._timer.setInterval(FLUSH_MS)
        self._timer.timeout.connect(self._flush)
        self._timer.start()

        t = self.ui.tableLog
        t.setColumnWidth(0, 90)
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)

        self.ui.btnClear.clicked.connect(self.clear)

    # ── public ────────────────────────────────────────────────

    def append_message(self, ts: float, level: str, source: str, text: str) -> None:
        """Slot for SystemLog.message(float, str, str, str). GUI-thread only (signal is queued)."""
        self._pending.append((ts, level, source, text))

    def clear(self) -> None:
        self._pending.clear()
        self.ui.tableLog.setRowCount(0)

    # ── internal ──────────────────────────────────────────────

    def _flush(self) -> None:
        if not self._pending:
            return
        t = self.ui.tableLog
        sb = t.verticalScrollBar()
        at_bottom = sb.value() >= sb.maximum() - 2     # follow only if user is at the bottom

        t.setUpdatesEnabled(False)
        try:
            while self._pending:
                ts, level, source, text = self._pending.popleft()
                row = t.rowCount()
                t.insertRow(row)

                time_item = QTableWidgetItem(datetime.fromtimestamp(ts).strftime("%H:%M:%S"))
                msg = f"[{source}] {text}"
                msg_item = QTableWidgetItem(msg)
                msg_item.setToolTip(msg)

                color = LEVEL_COLORS.get(level)
                if color is not None:
                    time_item.setForeground(color)
                    msg_item.setForeground(color)

                t.setItem(row, 0, time_item)
                t.setItem(row, 1, msg_item)

            if t.rowCount() > MAX_ROWS + TRIM_CHUNK:
                for _ in range(t.rowCount() - MAX_ROWS):
                    t.removeRow(0)
        finally:
            t.setUpdatesEnabled(True)

        if at_bottom:
            t.scrollToBottom()