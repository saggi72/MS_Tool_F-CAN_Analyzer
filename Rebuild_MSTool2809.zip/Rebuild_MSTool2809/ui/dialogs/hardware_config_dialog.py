"""
ui/dialogs/hardware_config_dialog.py
Menu Hardware > Hardware Configuration

Pure settings dialog: device types to scan, bus settings, diagnostic settings.
  - nothing is stored until Save is pressed (closing the dialog = cancel)
  - Save -> HwSettingsStore.apply() validates + persists + logs
  - never scans, never opens a bus (scan/connect live in the Channel Mapping dialog)

Generated UI: ui/generated/HardwareConfigDialog.py  (class Ui_dialogHardwareConfig)
    pyuic6 ui/designer/HardwareConfig_dialog.ui -o ui/generated/HardwareConfigDialog.py

Widget names this file relies on (rename in Designer if different):
    chkVector chkPeak chkCAN_Analyzer chkVirtual
    comboBoxBaudrate comboBoxType lblFDDataRate comboBoxDataRate editVectorApp
    editAppName editP2time editP2StarTime editSTmin comboBoxCanType
    btnSave
"""

from __future__ import annotations

import logging
import re
import sys
from typing import Optional

from PyQt6.QtCore import QLocale
from PyQt6.QtGui import QDoubleValidator, QIntValidator
from PyQt6.QtWidgets import QDialog, QMessageBox

from core.hardware import APP_NAME
from models.hw_settings import DiagnosticSettings, HwSettingsStore
from ui.generated.HardwareConfigDialog import Ui_dialogHardwareConfig   # <- adjust to your file name

logger = logging.getLogger(__name__)


def _parse_rate(text: str) -> int:
    """'125 kbit/s' -> 125000,  '1 Mbit/s' -> 1000000."""
    m = re.match(r"\s*([\d.]+)\s*([kKmM])", text)
    if not m:
        raise ValueError(f"Cannot parse bit rate: {text!r}")
    return int(round(float(m.group(1)) * (1_000 if m.group(2).lower() == "k" else 1_000_000)))


class HardwareConfigDialog(QDialog):

    def __init__(self, store: HwSettingsStore, hw_manager=None, parent=None) -> None:
        super().__init__(parent)
        self.ui = Ui_dialogHardwareConfig()
        self.ui.setupUi(self)
        self._store = store
        self._hw_manager = hw_manager       # optional: only used to warn when buses are live

        ui = self.ui
        self._backend_checks = {
            "VECTOR":       ui.chkVector,
            "PEAK":         ui.chkPeak,
            "CAN_ANALYZER": ui.chkCAN_Analyzer,
            "VIRTUAL":      ui.chkVirtual,
        }

        # Numbers live in itemData (parsed once from the Designer text)
        for combo in (ui.comboBoxBaudrate, ui.comboBoxDataRate):
            for i in range(combo.count()):
                combo.setItemData(i, _parse_rate(combo.itemText(i)))

        # Validators.  C locale: a Vietnamese locale would demand "0,2" instead of "0.2".
        c = QLocale.c()
        for edit in (ui.editP2time, ui.editP2StarTime):
            v = QIntValidator(1, 600_000, self)
            v.setLocale(c)
            edit.setValidator(v)
        dv = QDoubleValidator(0.0, 127.0, 1, self)
        dv.setNotation(QDoubleValidator.Notation.StandardNotation)
        dv.setLocale(c)
        ui.editSTmin.setValidator(dv)
        ui.editSTmin.setToolTip("0..127 (whole ms)  or  0.1..0.9 ms (step 0.1)")
        ui.editVectorApp.setToolTip(
            "Vector application name used by the Trace / Send CAN buses "
            f"(default {APP_NAME}).\nMust differ from the Diagnostic App Name.")
        ui.editAppName.setToolTip(
            "Vector application name used ONLY by Diagnostic (UDS).\n"
            "Shows in Vector Hardware Config which channel Diagnostic is attached to.")

        self._load_from_store()

        ui.comboBoxType.currentIndexChanged.connect(self._sync_fd_controls)
        ui.btnSave.clicked.connect(self._on_save)

    # ── store -> UI ───────────────────────────────────────────

    def _load_from_store(self) -> None:
        s, ui = self._store, self.ui

        for name, chk in self._backend_checks.items():
            chk.setChecked(name in s.backends)

        idx = ui.comboBoxBaudrate.findData(s.bitrate)
        ui.comboBoxBaudrate.setCurrentIndex(idx if idx >= 0 else ui.comboBoxBaudrate.findData(500_000))

        ui.comboBoxType.setCurrentIndex(1 if s.is_fd else 0)
        idx = ui.comboBoxDataRate.findData(s.fd_data_bitrate)
        ui.comboBoxDataRate.setCurrentIndex(idx if idx >= 0 else ui.comboBoxDataRate.findData(2_000_000))
        ui.editVectorApp.setText(s.app_name)

        d = s.diag
        ui.editAppName.setText(d.app_name)
        ui.editP2time.setText(str(d.p2_ms))
        ui.editP2StarTime.setText(str(d.p2_star_ms))
        ui.editSTmin.setText(f"{d.stmin_ms:g}")
        ui.comboBoxCanType.setCurrentIndex(1 if d.is_fd else 0)

        self._sync_fd_controls()

    def _sync_fd_controls(self) -> None:
        """FD data rate only for CAN FD bus; Diagnostic CANFD only if the bus is CAN FD."""
        ui = self.ui
        fd_bus = ui.comboBoxType.currentIndex() == 1
        ui.lblFDDataRate.setEnabled(fd_bus)
        ui.comboBoxDataRate.setEnabled(fd_bus)
        if not fd_bus:
            ui.comboBoxCanType.setCurrentIndex(0)
        ui.comboBoxCanType.setEnabled(fd_bus)

    # ── UI -> store ───────────────────────────────────────────

    def _on_save(self) -> None:
        ui = self.ui
        try:
            p2 = int(ui.editP2time.text())
            p2_star = int(ui.editP2StarTime.text())
        except ValueError:
            QMessageBox.warning(self, "Hardware Configuration", "P2 and P2* must be whole numbers (ms).")
            return
        try:
            stmin = float(ui.editSTmin.text().replace(",", "."))
        except ValueError:
            QMessageBox.warning(self, "Hardware Configuration", "STmin must be a number (ms).")
            return

        backends = [n for n, chk in self._backend_checks.items() if chk.isChecked()]
        if sys.platform != "win32" and "SOCKETCAN" in self._store.backends:
            backends.append("SOCKETCAN")        # no checkbox for it: keep what was stored

        diag = DiagnosticSettings(
            app_name=ui.editAppName.text().strip(),
            p2_ms=p2,
            p2_star_ms=p2_star,
            stmin_ms=stmin,
            is_fd=ui.comboBoxCanType.currentIndex() == 1,
        )
        err = self._store.apply(
            backends=backends,
            bitrate=ui.comboBoxBaudrate.currentData(),
            is_fd=ui.comboBoxType.currentIndex() == 1,
            fd_data_bitrate=ui.comboBoxDataRate.currentData(),
            app_name=ui.editVectorApp.text().strip() or APP_NAME,
            diag=diag,
        )
        if err:
            QMessageBox.warning(self, "Hardware Configuration", err)
            return                              # stay open so the user can fix it

        if self._hw_manager is not None and self._hw_manager.get_active_channel_count() > 0:
            logger.warning("Buses are connected: new bit rate / FD settings apply on the next Connect")
        self.accept()