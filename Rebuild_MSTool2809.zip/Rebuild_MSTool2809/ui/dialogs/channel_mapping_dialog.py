"""
ui/dialogs/channel_mapping_dialog.py
Menu Hardware > Hardware Channel Mapping

Maps logical CAN networks (from the database) to physical hardware channels,
in two independent tables:

    Measure Bus     — used by Trace / Send CAN      (Vector app "MS_Tool")
    Diagnostic Bus  — used by Diagnostic only       (Vector app "MS_Tool_Diagnostic")

This dialog never opens a bus.  Every change is saved to HwSettingsStore at once
(no OK button); the Start / Stop buttons on HOME read the stored mapping.

Buttons
    Refresh Network : re-read the network list from the database
    Scan Devices    : re-scan hardware (device types come from Hardware Configuration)

Generated UI: ui/generated/ChannelMappingDialog.py  (class Ui_dialogChannelMapping)
    pyuic6 ui/designer/MappingChannelDiaglog.ui -o ui/generated/ChannelMappingDialog.py
"""

from __future__ import annotations

import logging
from typing import Callable, Dict, List, Optional, Tuple

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QComboBox, QDialog, QHeaderView, QMessageBox, QTableWidget, QTableWidgetItem,
)

from core.hardware import HwScanThread, is_can_available
from models.hw_settings import (
    KIND_BUS, KIND_DIAG, HwSettingsStore, build_display_labels, describe_channel, hw_key,
)
from ui.generated.ChannelMappingDialog import Ui_dialogChannelMapping   # <- adjust to your file name

logger = logging.getLogger(__name__)

NetworkInfo = Tuple[str, str]            # (net_name, channel display e.g. "CH1")

COL_NO, COL_NAME, COL_BUS_CH, COL_ACTIVE, COL_HW = range(5)
NONE_TEXT = "(none)"
KIND_TITLE = {KIND_BUS: "Measure bus", KIND_DIAG: "Diagnostic bus"}


class ChannelMappingDialog(QDialog):

    def __init__(
        self,
        store: HwSettingsStore,
        networks_provider: Callable[[], List[NetworkInfo]],
        running: bool = False,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.ui = Ui_dialogChannelMapping()
        self.ui.setupUi(self)
        self._store = store
        self._provider = networks_provider
        self._running = running
        self._networks: List[NetworkInfo] = []
        self._scan_thread: Optional[HwScanThread] = None
        self._loading = False
        # (kind, net_name) -> (active combo, hardware combo)
        self._widgets: Dict[Tuple[str, str], Tuple[QComboBox, QComboBox]] = {}

        ui = self.ui
        self._tables = {KIND_BUS: ui.tableMesureBusMapping, KIND_DIAG: ui.tableDiagMapping}
        for table in self._tables.values():
            self._style_table(table)

        ui.btnRefreshNetwork.clicked.connect(self._on_refresh)
        ui.btnScan.clicked.connect(lambda: self._on_scan(interactive=True))

        if running:
            # Buses are live: editing would not apply until the next Start.
            self.setWindowTitle(self.windowTitle() + "  (read-only while running — press Stop to edit)")
            for table in self._tables.values():
                table.setEnabled(False)
            ui.btnScan.setEnabled(False)

        self._networks = list(self._provider())
        self._rebuild()

        # First open with nothing scanned yet: scan once automatically.
        if not running and not store.channels:
            QTimer.singleShot(0, lambda: self._on_scan(interactive=False))

    # ── table helpers ─────────────────────────────────────────

    @staticmethod
    def _style_table(table: QTableWidget) -> None:
        h = table.horizontalHeader()
        h.setSectionResizeMode(COL_NO,     QHeaderView.ResizeMode.Fixed)
        h.setSectionResizeMode(COL_NAME,   QHeaderView.ResizeMode.Interactive)
        h.setSectionResizeMode(COL_BUS_CH, QHeaderView.ResizeMode.Fixed)
        h.setSectionResizeMode(COL_ACTIVE, QHeaderView.ResizeMode.Fixed)
        h.setSectionResizeMode(COL_HW,     QHeaderView.ResizeMode.Stretch)
        table.setColumnWidth(COL_NO, 38)
        table.setColumnWidth(COL_NAME, 140)
        table.setColumnWidth(COL_BUS_CH, 90)
        table.setColumnWidth(COL_ACTIVE, 70)

    @staticmethod
    def _set_text(table, row, col, text, center=False, bold=False) -> None:
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        if center:
            item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        if bold:
            f = item.font()
            f.setBold(True)
            item.setFont(f)
        table.setItem(row, col, item)

    # ── build ─────────────────────────────────────────────────

    def _rebuild(self) -> None:
        """Rebuild both tables from (network list + scan result + stored mapping)."""
        self._loading = True
        try:
            self._widgets.clear()
            self._labels = build_display_labels(self._store.channels)
            for kind, table in self._tables.items():
                self._fill_table(kind, table)
        finally:
            self._loading = False

    def _fill_table(self, kind: str, table: QTableWidget) -> None:
        table.setRowCount(0)
        table.setRowCount(len(self._networks))
        saved = self._store.get_mapping(kind)

        for row, (net, ch_disp) in enumerate(self._networks):
            self._set_text(table, row, COL_NO, str(row + 1), center=True)
            self._set_text(table, row, COL_NAME, net, bold=True)
            self._set_text(table, row, COL_BUS_CH, ch_disp, center=True)

            entry = saved.get(net, {})

            active_cb = QComboBox()
            active_cb.addItems(["No", "Yes"])
            active_cb.setCurrentIndex(1 if entry.get("active") else 0)

            hw_cb = QComboBox()
            hw_cb.addItem(NONE_TEXT, "")
            for ch in self._store.channels:
                key = hw_key(ch)
                hw_cb.addItem(self._labels[key], key)
                hw_cb.setItemData(hw_cb.count() - 1, describe_channel(ch),
                                  Qt.ItemDataRole.ToolTipRole)
            key = str(entry.get("hw_key", ""))
            if key:
                idx = hw_cb.findData(key)
                if idx < 0:         # unplugged since the last session: keep it visible, never silently drop
                    hw_cb.addItem(f"(not found) {key.replace('|', ' ')}", key)
                    idx = hw_cb.count() - 1
                hw_cb.setCurrentIndex(idx)

            self._widgets[(kind, net)] = (active_cb, hw_cb)
            active_cb.currentIndexChanged.connect(lambda _i, k=kind, n=net: self._on_changed(k, n))
            hw_cb.currentIndexChanged.connect(lambda _i, k=kind, n=net: self._on_changed(k, n))
            table.setCellWidget(row, COL_ACTIVE, active_cb)
            table.setCellWidget(row, COL_HW, hw_cb)

        table.resizeRowsToContents()

    # ── user edits (saved immediately) ────────────────────────

    def _on_changed(self, kind: str, net: str) -> None:
        if self._loading:
            return
        active_cb, hw_cb = self._widgets[(kind, net)]
        active = active_cb.currentIndex() == 1
        key = str(hw_cb.currentData() or "")

        # One physical channel can serve only one ACTIVE network per table.
        # (Measure and Diagnostic MAY share a channel: they are separate Vector apps.)
        if active and key:
            for (k2, n2), (a2, h2) in self._widgets.items():
                if (k2 == kind and n2 != net and a2.currentIndex() == 1
                        and str(h2.currentData() or "") == key):
                    logger.warning(
                        "%s: '%s' not changed — %s is already used by '%s'",
                        KIND_TITLE[kind], net, hw_cb.currentText(), n2)
                    self._revert(kind, net)
                    return

        self._store.set_mapping(kind, net, active, key)
        logger.info("%s: '%s' -> %s [%s]", KIND_TITLE[kind], net,
                    hw_cb.currentText(), "active" if active else "inactive")

    def _revert(self, kind: str, net: str) -> None:
        active_cb, hw_cb = self._widgets[(kind, net)]
        prev = self._store.get_mapping(kind).get(net, {})
        idx = hw_cb.findData(str(prev.get("hw_key", ""))) if prev.get("hw_key") else 0
        for w in (active_cb, hw_cb):
            w.blockSignals(True)
        active_cb.setCurrentIndex(1 if prev.get("active") else 0)
        hw_cb.setCurrentIndex(max(idx, 0))
        for w in (active_cb, hw_cb):
            w.blockSignals(False)

    # ── buttons ───────────────────────────────────────────────

    def _on_refresh(self) -> None:
        self._networks = list(self._provider())
        self._rebuild()
        logger.info("Channel mapping: %d network(s) refreshed from database", len(self._networks))

    def _on_scan(self, interactive: bool) -> None:
        if self._scan_thread is not None:
            return
        # python-can is imported lazily; do the FIRST import here on the GUI thread
        # (importing it first inside a worker thread can hit DLL conflicts on Windows).
        if not is_can_available():
            logger.error("python-can is not installed (pip install python-can)")
            if interactive:
                QMessageBox.critical(self, "Missing library",
                                     "python-can is required.\nInstall:  pip install python-can")
            return
        backends = list(self._store.backends)
        if not backends:
            logger.warning("Scan skipped: no device type selected in Hardware Configuration")
            return

        self.ui.btnScan.setEnabled(False)
        logger.info("Scanning hardware: %s", ", ".join(backends))
        self._scan_thread = HwScanThread(backends, parent=self)
        self._scan_thread.scan_complete.connect(self._on_scan_done)
        self._scan_thread.scan_error.connect(self._on_scan_error)
        self._scan_thread.start()

    def _on_scan_done(self, channels: list) -> None:
        self._scan_thread = None
        self.ui.btnScan.setEnabled(not self._running)
        self._store.set_channels(channels)
        self._rebuild()                         # stored selections are re-applied by hw_key
        labels = build_display_labels(channels)
        for ch in channels:
            logger.info("  Found: %s", labels[hw_key(ch)])
        logger.info("Scan complete: %d hardware channel(s)", len(channels))

    def _on_scan_error(self, msg: str) -> None:
        self._scan_thread = None
        self.ui.btnScan.setEnabled(not self._running)
        logger.error("Scan failed: %s", msg)

    # ── close ─────────────────────────────────────────────────

    def done(self, result: int) -> None:
        if self._scan_thread is not None:
            try:
                self._scan_thread.scan_complete.disconnect()
                self._scan_thread.scan_error.disconnect()
            except TypeError:
                pass
            self._scan_thread.wait(5000)
            self._scan_thread = None
        super().done(result)