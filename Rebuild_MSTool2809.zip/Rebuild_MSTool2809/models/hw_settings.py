"""
models/hw_settings.py
Shared state between the Hardware dialogs.

    dialogHardwareConfig   -> WRITES  backends, bus settings, diagnostic settings
    dialogChannelMapping   -> READS   all of the above, WRITES channels + bus/diag mapping

MainWindow creates ONE HwSettingsStore and passes it to both dialogs
(and later to the Start/Stop controller, which reads active_mapping()).
Persisted with QSettings, so settings survive an app restart.
No widgets, no bus logic: data + validation + signals.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional, Tuple

from PyQt6.QtCore import QObject, QSettings, pyqtSignal

from core.hardware import APP_NAME, DEFAULT_FD_DATA_BITRATE, HwChannel

logger = logging.getLogger(__name__)

ALL_BACKENDS = ["VECTOR", "PEAK", "CAN_ANALYZER", "SOCKETCAN", "VIRTUAL"]

# Mapping kinds: which Vector application owns the bus
KIND_BUS  = "bus"      # Measure bus   (Trace / Send CAN)  -> app name "MS_Tool"
KIND_DIAG = "diag"     # Diagnostic bus (UDS)              -> app name "MS_Tool_Diagnostic"
DEFAULT_DIAG_APP_NAME = "MS_Tool_Diagnostic"

# Vector XL application name: XL_MAX_APPNAME is 32 including the terminating NUL.
MAX_APP_NAME_LEN = 31


# ──────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────

def hw_key(ch: HwChannel) -> str:
    """Stable identity of a physical channel (two identical VN1640 differ by serial)."""
    return f"{ch.interface}|{ch.channel}|{ch.serial or ''}"


def _device_id(ch: HwChannel) -> str:
    """One id per physical device (a VN1640 has 4 channels but ONE serial)."""
    return str(ch.serial) if ch.serial else f"idx{ch.hw_index}"


def describe_channel(ch: HwChannel) -> str:
    """Tooltip text for a hardware channel."""
    parts = [ch.interface, f"channel {ch.channel}"]
    if ch.serial:
        parts.append(f"serial {ch.serial}")
    return " · ".join(parts)


def build_display_labels(channels: List[HwChannel]) -> Dict[str, str]:
    """
    hw_key -> text shown in the hardware combo boxes.

    Two identical devices (same model, different serial) would both be listed as
    "Vector VN1640A Ch1".  When a model group has several devices AND its labels
    repeat, every channel of that group gets the device ordinal as a prefix:

        [1] Vector VN1640A Ch1        [2] Vector VN1640A Ch1

    Ordinals follow hw_index (then serial), so they are stable between scans.
    Single devices keep their plain label.
    """
    labels: Dict[str, str] = {hw_key(c): c.label for c in channels}

    groups: Dict[Tuple[str, str], List[HwChannel]] = {}
    for c in channels:
        groups.setdefault((c.interface, c.model), []).append(c)

    for chs in groups.values():
        order: Dict[str, Tuple[int, str]] = {}
        for c in chs:
            order.setdefault(_device_id(c), (c.hw_index, _device_id(c)))
        if len(order) < 2 or len({c.label for c in chs}) == len(chs):
            continue                                  # one device, or labels already unique
        ordinal = {dev: n for n, (dev, _) in
                   enumerate(sorted(order.items(), key=lambda kv: kv[1]), start=1)}
        for c in chs:
            labels[hw_key(c)] = f"[{ordinal[_device_id(c)]}] {c.label}"
    return labels


def stmin_ms_to_byte(ms: float) -> int:
    """
    ISO 15765-2 STmin encoding.
        0 .. 127 ms (whole numbers)  -> 0x00 .. 0x7F
        0.1 .. 0.9 ms (step 0.1)     -> 0xF1 .. 0xF9
    Raises ValueError for anything else.
    """
    if 0 <= ms <= 127 and float(ms).is_integer():
        return int(ms)
    for tenth in range(1, 10):
        if abs(ms - tenth / 10) < 1e-6:
            return 0xF0 + tenth
    raise ValueError(
        f"STmin {ms} ms is not encodable: use 0..127 (whole ms) or 0.1..0.9 (step 0.1)"
    )


# ──────────────────────────────────────────────────────────────
# Diagnostic settings
# ──────────────────────────────────────────────────────────────

@dataclass
class DiagnosticSettings:
    app_name:   str   = DEFAULT_DIAG_APP_NAME
    p2_ms:      int   = 1000
    p2_star_ms: int   = 5000
    stmin_ms:   float = 0.2
    is_fd:      bool  = False        # UDS frames: classic CAN (False) / CAN FD (True)

    @property
    def stmin_byte(self) -> int:
        return stmin_ms_to_byte(self.stmin_ms)


# ──────────────────────────────────────────────────────────────
# Store
# ──────────────────────────────────────────────────────────────

class HwSettingsStore(QObject):
    channels_changed = pyqtSignal(list)   # List[HwChannel]
    settings_changed = pyqtSignal()       # anything saved from the config dialog
    mapping_changed  = pyqtSignal()       # a row of Measure/Diag mapping changed

    _QS_ORG, _QS_APP, _QS_KEY = "MS_Tool", "MS_Tool_F", "hardware/json"

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.backends: List[str] = ["VECTOR", "PEAK"]
        self.bitrate: int = 500_000
        self.is_fd: bool = False
        self.fd_data_bitrate: int = DEFAULT_FD_DATA_BITRATE
        self.app_name: str = APP_NAME            # Vector xlSetApplConfig name
        self.diag = DiagnosticSettings()

        # Runtime only (not persisted): result of the last scan
        self.channels: List[HwChannel] = []
        # Persisted: net_name -> {"active": bool, "hw_key": str}
        self.bus_mapping:  Dict[str, Dict[str, object]] = {}    # Measure bus
        self.diag_mapping: Dict[str, Dict[str, object]] = {}    # Diagnostic bus

        self.load()

    # ── config dialog -> store ────────────────────────────────

    def apply(
        self,
        backends: List[str],
        bitrate: int,
        is_fd: bool,
        fd_data_bitrate: int,
        app_name: str,
        diag: DiagnosticSettings,
    ) -> Optional[str]:
        """Validate + store + persist.  Returns an error message, or None on success."""
        app_name = app_name.strip() or APP_NAME
        diag.app_name = diag.app_name.strip() or DEFAULT_DIAG_APP_NAME
        err = self._validate(backends, bitrate, is_fd, app_name, diag)
        if err:
            return err

        self.backends = list(backends)
        self.bitrate = int(bitrate)
        self.is_fd = bool(is_fd)
        self.fd_data_bitrate = int(fd_data_bitrate)
        self.app_name = app_name
        self.diag = diag

        self.save()
        self.settings_changed.emit()
        logger.info(
            "Hardware settings saved: %s, %s%s, backends=%s, apps: bus='%s' diag='%s', P2=%d P2*=%d STmin=%gms (0x%02X)",
            f"{self.bitrate // 1000} kbit/s",
            "CAN FD" if self.is_fd else "CAN",
            f" data {self.fd_data_bitrate // 1000} kbit/s" if self.is_fd else "",
            ",".join(self.backends), self.app_name, diag.app_name, diag.p2_ms, diag.p2_star_ms,
            diag.stmin_ms, diag.stmin_byte,
        )
        return None

    @staticmethod
    def _validate(backends, bitrate, is_fd, app_name: str, diag: DiagnosticSettings) -> Optional[str]:
        # The two Vector application names must be distinct and valid, otherwise
        # Vector Hardware Config cannot show which one (Trace/Send vs Diagnostic)
        # is attached to a channel.
        for label, name in (("Vector App (Bus)", app_name), ("Diagnostic App Name", diag.app_name)):
            if len(name) > MAX_APP_NAME_LEN:
                return f"{label} is too long (max {MAX_APP_NAME_LEN} characters)."
        if app_name.casefold() == diag.app_name.casefold():
            return ("Vector App (Bus) and Diagnostic App Name must be different, "
                    "so Vector Hardware Config can tell them apart.")
        if not backends:
            return "Select at least one device type."
        if bitrate <= 0:
            return "Baudrate must be greater than 0."
        if diag.p2_ms <= 0 or diag.p2_star_ms <= 0:
            return "P2 and P2* must be greater than 0."
        if diag.p2_star_ms < diag.p2_ms:
            return "P2* must be greater than or equal to P2."
        try:
            _ = diag.stmin_byte
        except ValueError as e:
            return str(e)
        if diag.is_fd and not is_fd:
            return "Diagnostic CAN type is CANFD, but the bus type is CAN. Set the bus type to CAN FD first."
        return None

    # ── mapping dialog -> store ───────────────────────────────

    def set_channels(self, channels: List[HwChannel]) -> None:
        self.channels = list(channels)
        self.channels_changed.emit(self.channels)

    def get_mapping(self, kind: str) -> Dict[str, Dict[str, object]]:
        return self.bus_mapping if kind == KIND_BUS else self.diag_mapping

    def set_mapping(self, kind: str, net_name: str, active: bool, key: str) -> None:
        self.get_mapping(kind)[net_name] = {"active": bool(active), "hw_key": key}
        self.save()
        self.mapping_changed.emit()

    def rename_network(self, old: str, new: str) -> None:
        """Keep mappings when a network is renamed in the database."""
        changed = False
        for kind in (KIND_BUS, KIND_DIAG):
            m = self.get_mapping(kind)
            if old in m:
                m[new] = m.pop(old)
                changed = True
        if changed:
            self.save()
            self.mapping_changed.emit()

    def active_mapping(self, kind: str) -> Dict[str, str]:
        """{net_name: hw_key} for every row that is Active and has hardware chosen."""
        return {n: str(e["hw_key"]) for n, e in self.get_mapping(kind).items()
                if e.get("active") and e.get("hw_key")}

    def resolve(self, key: str) -> Optional[HwChannel]:
        """HwChannel of the last scan for a stored hw_key (None if not plugged in)."""
        for c in self.channels:
            if hw_key(c) == key:
                return c
        return None

    # ── persistence ───────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "backends": self.backends,
            "bitrate": self.bitrate,
            "is_fd": self.is_fd,
            "fd_data_bitrate": self.fd_data_bitrate,
            "app_name": self.app_name,
            "diag": asdict(self.diag),
            "bus_mapping": self.bus_mapping,
            "diag_mapping": self.diag_mapping,
        }

    def save(self) -> None:
        try:
            qs = QSettings(self._QS_ORG, self._QS_APP)
            qs.setValue(self._QS_KEY, json.dumps(self.to_dict()))
            qs.sync()
        except Exception as e:
            logger.warning("Hardware settings not saved: %s", e)

    def load(self) -> None:
        try:
            raw = QSettings(self._QS_ORG, self._QS_APP).value(self._QS_KEY, "")
            if not raw:
                return
            d = json.loads(raw)
            backends = [b for b in d.get("backends", []) if b in ALL_BACKENDS]
            if backends:
                self.backends = backends
            self.bitrate = int(d.get("bitrate", self.bitrate))
            self.is_fd = bool(d.get("is_fd", self.is_fd))
            self.fd_data_bitrate = int(d.get("fd_data_bitrate", self.fd_data_bitrate))
            self.app_name = str(d.get("app_name", self.app_name)).strip() or APP_NAME
            dd = d.get("diag", {})
            self.diag = DiagnosticSettings(
                app_name=str(dd.get("app_name", DEFAULT_DIAG_APP_NAME)).strip() or DEFAULT_DIAG_APP_NAME,
                p2_ms=int(dd.get("p2_ms", 1000)),
                p2_star_ms=int(dd.get("p2_star_ms", 5000)),
                stmin_ms=float(dd.get("stmin_ms", 0.2)),
                is_fd=bool(dd.get("is_fd", False)),
            )
            self.bus_mapping = dict(d.get("bus_mapping", {}))
            self.diag_mapping = dict(d.get("diag_mapping", {}))
        except Exception as e:
            logger.warning("Hardware settings load failed, using defaults: %s", e)