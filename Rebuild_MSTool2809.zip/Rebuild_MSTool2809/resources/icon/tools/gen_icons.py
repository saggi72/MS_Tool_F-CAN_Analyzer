from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "resources" / "icons"

COLOR = "#5f6368"
TEMPLATE = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
    f'stroke="{COLOR}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
    "{body}</svg>"
)

ICONS = {
    "pause": f'<rect x="6" y="5" width="4" height="14" fill="{COLOR}" stroke="none"/>'
             f'<rect x="14" y="5" width="4" height="14" fill="{COLOR}" stroke="none"/>',
    "play": f'<polygon points="7,4 20,12 7,20" fill="{COLOR}" stroke="none"/>',
    "save": '<path d="M5 3h11l3 3v15H5z"/><rect x="8" y="3" width="7" height="6"/>'
            '<rect x="8" y="14" width="8" height="7"/>',
    "clear": '<path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13h10l1-13"/>'
             '<path d="M10 11v5M14 11v5"/>',
    "autoscroll": '<path d="M12 4v13"/><path d="M6 12l6 6 6-6"/><path d="M5 21h14"/>',
    "expand": '<path d="M6 5l6 5 6-5"/><path d="M6 13l6 5 6-5"/>',
    "collapse": '<path d="M6 11l6-5 6 5"/><path d="M6 19l6-5 6 5"/>',
    "snapshot": '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    "settings": '<path d="M4 7h3M11 7h9"/><circle cx="9" cy="7" r="2"/>'
                '<path d="M4 12h9M17 12h3"/><circle cx="15" cy="12" r="2"/>'
                '<path d="M4 17h5M13 17h7"/><circle cx="11" cy="17" r="2"/>',
    "filter": '<path d="M4 5h16l-6 8v6l-4-2v-4z"/>',

    "edit": '<path d="M4 20h4l11-11-4-4L4 16z"/><path d="M13 7l4 4"/>',
    "folder": '<path d="M3 7h7l2 2h9v10H3z"/>',
    "reload": '<path d="M20 12a8 8 0 1 1-3-6.2"/><path d="M20 4v5h-5"/>',
    "close": '<path d="M6 6l12 12M18 6L6 18"/>',
    "add": '<path d="M12 5v14M5 12h14"/>',
    "remove": '<path d="M5 12h14"/>',
    "export": '<path d="M12 4v11"/><path d="M7 10l5 5 5-5"/><path d="M5 20h14"/>',
}

OUT.mkdir(parents=True, exist_ok=True)
for name, body in ICONS.items():
    (OUT / f"{name}.svg").write_text(TEMPLATE.format(body=body), encoding="utf-8")
    print("wrote", OUT / f"{name}.svg")