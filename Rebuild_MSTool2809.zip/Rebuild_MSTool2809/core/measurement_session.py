"""
==============================================================
core/measurement_session.py
Start / Stop of the whole measurement (HOME > Start, HOME > Stop)
==============================================================

Owns the *running* state of the application.

    Start : build one bus per ACTIVE row of the Measure Bus mapping
            (Channel Mapping dialog) and connect them through HardwareManager.
    Stop  : disconnect every bus.

The Channel Mapping dialog never connects anything; it only edits the mapping
stored in HwSettingsStore.  Everything that must follow the run state
(dialogs, Trace, Graphic, ...) listens to `running_changed(bool)`.

Not here yet (next sub-steps): RX frames -> Trace, Diagnostic bus.
"""

from __future__ import annotations

import logging
import time
from typing import Dict, Tuple

from PyQt6.QtCore import QObject, pyqtSignal

from core.hardware import (
    HardwareConfigHelper,
    HardwareManager,
    HwScanner,
    is_can_available,
)
from models.hw_settings import KIND_BUS, KIND_DIAG, HwSettingsStore, build_display_labels

logger = logging.getLogger(__name__)

ERROR_REPEAT_S = 5.0     # the same bus error is logged at most once per 5 s


class MeasurementSession(QObject):
    running_changed = pyqtSignal(bool)

    def __init__(self, store: HwSettingsStore, database, hw_manager: HardwareManager,
                 parent=None) -> None:
        super().__init__(parent)
        self._store = store
        self._db = database            # DatabaseManager (needs .networks)
        self._hw = hw_manager
        self._running = False
        self._last_error: Dict[Tuple[str, str], float] = {}
        self._hw.network_error.connect(self._on_network_error)

    @property
    def is_running(self) -> bool:
        return self._running

    # ── Start ─────────────────────────────────────────────────

    def start(self) -> bool:
        """Connect every active Measure-bus network.  Returns True if at least one started."""
        if self._running:
            return True

        wanted = self._store.active_mapping(KIND_BUS)           # {net_name: hw_key}
        nets = sorted(self._db.networks.values(), key=lambda n: n.channel_index or 0)
        jobs = [(n.name, wanted[n.name]) for n in nets if n.name in wanted]
        if not jobs:
            logger.warning("Start: no active network in Channel Mapping (Measure Bus)")
            return False

        # Scan results are not persisted: after an app restart the hardware list is empty.
        if any(self._store.resolve(key) is None for _, key in jobs):
            self._scan_now()

        labels = build_display_labels(self._store.channels)
        s = self._store
        used: Dict[str, str] = {}
        started = 0

        for net, key in jobs:
            hw = s.resolve(key)
            if hw is None:
                logger.warning("Start: '%s' skipped — mapped hardware not found (not plugged in?)", net)
                continue
            if key in used:
                logger.warning("Start: '%s' skipped — %s is already used by '%s'",
                               net, labels[key], used[key])
                continue

            cfg = HardwareConfigHelper.to_network_config(
                hw_channel=hw, net_name=net, bitrate=s.bitrate, is_fd=s.is_fd,
                fd_data_bitrate=s.fd_data_bitrate, app_name=s.app_name,
            )
            if net in self._hw.get_network_names():
                self._hw.remove_network(net)
            self._hw.add_network(cfg)

            if self._hw.start_network(net):
                used[key] = net
                started += 1
                logger.info("Started '%s' on %s @ %d kbit/s%s (app '%s')", net, labels[key],
                            s.bitrate // 1000,
                            f" FD {s.fd_data_bitrate // 1000} kbit/s" if s.is_fd else "",
                            s.app_name)
            else:
                self._hw.remove_network(net)
                logger.error("Start: '%s' FAILED to connect on %s", net, labels[key])

        if started == 0:
            logger.warning("Start failed: no network could be started")
            return False

        if self._store.active_mapping(KIND_DIAG):
            logger.info("Diagnostic bus mapping is stored; the Diagnostic bus is not started yet")

        self._running = True
        logger.info("Measurement started: %d/%d network(s)", started, len(jobs))
        self.running_changed.emit(True)
        return True

    def _scan_now(self) -> None:
        if not is_can_available():
            logger.error("python-can is not installed (pip install python-can)")
            return
        logger.info("Hardware list is empty — scanning before Start")
        try:
            self._store.set_channels(HwScanner.scan(self._store.backends))
        except Exception as e:
            logger.error("Scan before Start failed: %s", e)

    # ── Stop ──────────────────────────────────────────────────

    def stop(self) -> None:
        """Disconnect every bus."""
        names = list(self._hw.get_network_names())
        if not self._running and not names:
            return
        for nn in names:
            self._hw.remove_network(nn)             # stops the RX thread + closes the bus
        self._running = False
        self._last_error.clear()
        logger.info("Measurement stopped (%d network(s) closed)", len(names))
        self.running_changed.emit(False)

    # ── bus errors ────────────────────────────────────────────

    def _on_network_error(self, net: str, msg: str) -> None:
        """RX threads can report the same error every 100 ms (e.g. cable pulled): throttle it."""
        now = time.monotonic()
        key = (net, msg)
        if now - self._last_error.get(key, -1e9) < ERROR_REPEAT_S:
            return
        if len(self._last_error) > 200:
            self._last_error.clear()
        self._last_error[key] = now
        logger.error("NET[%s]: %s", net, msg)